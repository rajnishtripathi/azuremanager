# Restaurent-POS-System
A point of sale system for a restaurant, developed using C# and .NET Framework.

Demonstration video:


https://user-images.githubusercontent.com/32706881/174109078-e164c031-cfea-4609-a4ee-67c04deb309f.mp4

