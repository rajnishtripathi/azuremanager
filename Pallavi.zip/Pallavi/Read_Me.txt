copy DB folder in C drive
double click on POS 
login to the application
user name: admin
Password : admin